
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/data-entry')
def data_entry():
    return render_template('data_entry.html')

@app.route('/results', methods=['POST'])
def results():
    surface = request.form.get('surface', type=float)
    volume = request.form.get('volume', type=float)
    length = request.form.get('length', type=float)
    # Exemple de calcul (ajoutez vos formules ici)
    result = surface * 250 if surface else 0
    return render_template('results.html', result=result)

@app.route('/guide')
def guide():
    return render_template('guide.html')

if __name__ == '__main__':
    app.run(debug=True)
